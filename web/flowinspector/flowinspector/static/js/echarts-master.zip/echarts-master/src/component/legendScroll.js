/**
 * Legend component entry file8
 */
define(function (require) {

    require('./legend');

    require('./legend/ScrollableLegendModel');
    require('./legend/ScrollableLegendView');
    require('./legend/scrollableLegendAction');

});