define(function(require) {

    require('./gridSimple');

    require('./axisPointer/CartesianAxisPointer');

    require('./axisPointer');

});